{
    'name': 'Duplicate Customer identification',
    'version': '1.0',
    'category': 'Custom Module',
    'author': 'Ashif Raihun',
    'summary': 'Customer identification',
    'description': 'Duplicate Customer identification',
    'depends': ['base','sale'],
    'data':['view/duplicate_customer_identification_script.xml'],
    'installable': True,
    'application': True,
    'auto_install': False,
}
